package com.neyaz.HitUrlCounter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HitUrlCounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
